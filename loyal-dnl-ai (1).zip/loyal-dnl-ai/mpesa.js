// Thin client for Safaricom Daraja (M-Pesa Express / STK Push).
const BASES = {
  sandbox: 'https://sandbox.safaricom.co.ke',
  production: 'https://api.safaricom.co.ke',
};

function config() {
  const env = process.env.MPESA_ENV === 'production' ? 'production' : 'sandbox';
  const shortcode = process.env.MPESA_SHORTCODE;
  return {
    base: BASES[env],
    key: process.env.MPESA_CONSUMER_KEY,
    secret: process.env.MPESA_CONSUMER_SECRET,
    shortcode,
    partyB: process.env.MPESA_PARTY_B || shortcode,
    passkey: process.env.MPESA_PASSKEY,
    type: process.env.MPESA_TRANSACTION_TYPE || 'CustomerPayBillOnline',
  };
}

function isConfigured() {
  const c = config();
  return Boolean(c.key && c.secret && c.shortcode && c.passkey);
}

// Daraja wants YYYYMMDDHHmmss in East Africa Time.
function timestamp() {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Africa/Nairobi',
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(new Date());
  const get = (t) => parts.find((p) => p.type === t).value;
  return `${get('year')}${get('month')}${get('day')}${get('hour')}${get('minute')}${get('second')}`;
}

let cachedToken = null; // { value, expiresAt }

async function getToken() {
  if (cachedToken && cachedToken.expiresAt > Date.now() + 30_000) return cachedToken.value;
  const c = config();
  const auth = Buffer.from(`${c.key}:${c.secret}`).toString('base64');
  const res = await fetch(`${c.base}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: `Basic ${auth}` },
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) throw new Error(`M-Pesa auth failed (${res.status})`);
  const data = await res.json();
  cachedToken = {
    value: data.access_token,
    expiresAt: Date.now() + (Number(data.expires_in) || 3000) * 1000,
  };
  return cachedToken.value;
}

async function post(path, body) {
  const token = await getToken();
  const res = await fetch(`${config().base}${path}`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(20_000),
  });
  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, data };
}

function passwordFor(ts) {
  const c = config();
  return Buffer.from(`${c.shortcode}${c.passkey}${ts}`).toString('base64');
}

/**
 * Sends the "Enter your M-Pesa PIN" prompt to the customer's phone.
 * phone must be in 2547XXXXXXXX / 2541XXXXXXXX format.
 */
async function stkPush({ phone, amount, callbackUrl, reference, description }) {
  const c = config();
  const ts = timestamp();
  const { ok, data } = await post('/mpesa/stkpush/v1/processrequest', {
    BusinessShortCode: c.shortcode,
    Password: passwordFor(ts),
    Timestamp: ts,
    TransactionType: c.type,
    Amount: amount,
    PartyA: phone,
    PartyB: c.partyB,
    PhoneNumber: phone,
    CallBackURL: callbackUrl,
    AccountReference: String(reference).slice(0, 12),
    TransactionDesc: String(description).slice(0, 13),
  });
  if (!ok || String(data.ResponseCode) !== '0') {
    throw new Error(data.errorMessage || data.ResponseDescription || 'Could not start M-Pesa payment');
  }
  return { checkoutRequestId: data.CheckoutRequestID, merchantRequestId: data.MerchantRequestID };
}

/**
 * Asks Safaricom what happened to a payment. Used as a fallback when the callback hasn't arrived
 * (for example on localhost, where Safaricom can't reach you).
 * Returns { state: 'pending' | 'success' | 'failed', desc }.
 */
async function stkQuery(checkoutRequestId) {
  const c = config();
  const ts = timestamp();
  const { data } = await post('/mpesa/stkpushquery/v1/query', {
    BusinessShortCode: c.shortcode,
    Password: passwordFor(ts),
    Timestamp: ts,
    CheckoutRequestID: checkoutRequestId,
  });
  // While the customer is still deciding, Daraja answers with an error body instead of a ResultCode.
  if (data.ResultCode === undefined) return { state: 'pending', desc: data.errorMessage || 'Processing' };
  if (String(data.ResultCode) === '0') return { state: 'success', desc: data.ResultDesc };
  return { state: 'failed', desc: data.ResultDesc || 'Payment was not completed' };
}

// 07XXXXXXXX, 01XXXXXXXX, +2547XXXXXXXX, 2547XXXXXXXX -> 2547XXXXXXXX. Returns null if invalid.
function normalizePhone(input) {
  const digits = String(input || '').replace(/[\s\-()]/g, '').replace(/^\+/, '');
  let p = digits;
  if (/^0[17]\d{8}$/.test(digits)) p = `254${digits.slice(1)}`;
  return /^254[17]\d{8}$/.test(p) ? p : null;
}

module.exports = { isConfigured, stkPush, stkQuery, normalizePhone };
