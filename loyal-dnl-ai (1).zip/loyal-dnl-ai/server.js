require('dotenv').config();

const crypto = require('crypto');
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const { db, consumeQuota, refundQuota, usedToday } = require('./db');
const ai = require('./ai');
const mpesa = require('./mpesa');

// ---------- config ----------
const isProd = process.env.NODE_ENV === 'production';
const PORT = Number(process.env.PORT) || 3000;
const BASE_URL = (process.env.BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
const FREE_LIMIT = Number(process.env.FREE_DAILY_LIMIT) || 3;
const PRO_LIMIT = Number(process.env.PRO_DAILY_LIMIT) || 100;
const PRO_PRICE = Number(process.env.PRO_PRICE_KES) || 300;
const PRO_DAYS = Number(process.env.PRO_DAYS) || 30;
const MOCK_MPESA = process.env.MPESA_MOCK === 'true' && !isProd;
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || '').toLowerCase();

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error('JWT_SECRET is missing or too short (use at least 32 characters). See .env.example.');
  process.exit(1);
}

let CALLBACK_SECRET = process.env.MPESA_CALLBACK_SECRET;
if (!CALLBACK_SECRET) {
  if (isProd) {
    console.error('MPESA_CALLBACK_SECRET is required in production. See .env.example.');
    process.exit(1);
  }
  CALLBACK_SECRET = crypto.randomBytes(16).toString('hex');
  console.warn('MPESA_CALLBACK_SECRET not set: using a random one for this run (dev only).');
}

// ---------- app ----------
const app = express();
if (isProd) app.set('trust proxy', 1);
app.disable('x-powered-by');

app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        'default-src': ["'self'"],
        'script-src': ["'self'"],
        'style-src': ["'self'", 'https://fonts.googleapis.com'],
        'font-src': ["'self'", 'https://fonts.gstatic.com'],
        'img-src': ["'self'", 'data:'],
        'connect-src': ["'self'"],
        'upgrade-insecure-requests': isProd ? [] : null,
      },
    },
  })
);
app.use(express.json({ limit: '20kb' }));
app.use(cookieParser());

const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const limiter = (windowMs, max) =>
  rateLimit({ windowMs, max, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many requests. Please slow down.' } });

// ---------- helpers ----------
const isPro = (u) => Boolean(u.pro_until && new Date(u.pro_until) > new Date());
const dailyLimit = (u) => (isPro(u) ? PRO_LIMIT : FREE_LIMIT);

function publicUser(u) {
  const limit = dailyLimit(u);
  const used = usedToday(u.id);
  return {
    id: u.id,
    name: u.name,
    email: u.email,
    plan: isPro(u) ? 'pro' : 'free',
    proUntil: isPro(u) ? u.pro_until : null,
    usedToday: used,
    dailyLimit: limit,
    remainingToday: Math.max(limit - used, 0),
    isAdmin: Boolean(ADMIN_EMAIL && u.email === ADMIN_EMAIL),
  };
}

function setSession(res, userId) {
  const token = jwt.sign({ uid: userId }, JWT_SECRET, { expiresIn: '30d' });
  res.cookie('token', token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: isProd,
    maxAge: 30 * 24 * 3600 * 1000,
  });
}

const getUserById = db.prepare('SELECT * FROM users WHERE id = ?');
const getUserByEmail = db.prepare('SELECT * FROM users WHERE email = ?');

function requireAuth(req, res, next) {
  try {
    const payload = jwt.verify(req.cookies.token || '', JWT_SECRET);
    const user = getUserById.get(payload.uid);
    if (!user) throw new Error('no user');
    req.user = user;
    next();
  } catch {
    res.status(401).json({ error: 'Please log in' });
  }
}

const clean = (v, max) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, max);

// A hash of a random string, used so login takes similar time whether or not the email exists.
const DUMMY_HASH = bcrypt.hashSync(crypto.randomBytes(8).toString('hex'), 10);

// ---------- auth ----------
app.post(
  '/api/auth/register',
  limiter(15 * 60 * 1000, 20),
  wrap(async (req, res) => {
    const name = clean(req.body.name, 60);
    const email = clean(req.body.email, 120).toLowerCase();
    const password = String(req.body.password || '');
    if (!name) return res.status(400).json({ error: 'Please enter your name' });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Please enter a valid email' });
    if (password.length < 8 || password.length > 100) return res.status(400).json({ error: 'Password must be 8 to 100 characters' });
    if (getUserByEmail.get(email)) return res.status(409).json({ error: 'An account with this email already exists' });

    const hash = await bcrypt.hash(password, 10);
    const info = db.prepare('INSERT INTO users (email, name, password_hash) VALUES (?, ?, ?)').run(email, name, hash);
    setSession(res, info.lastInsertRowid);
    res.status(201).json({ user: publicUser(getUserById.get(info.lastInsertRowid)) });
  })
);

app.post(
  '/api/auth/login',
  limiter(15 * 60 * 1000, 20),
  wrap(async (req, res) => {
    const email = clean(req.body.email, 120).toLowerCase();
    const password = String(req.body.password || '');
    const user = getUserByEmail.get(email);
    const ok = await bcrypt.compare(password, user ? user.password_hash : DUMMY_HASH);
    if (!user || !ok) return res.status(401).json({ error: 'Wrong email or password' });
    setSession(res, user.id);
    res.json({ user: publicUser(user) });
  })
);

app.post('/api/auth/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ ok: true });
});

app.get('/api/me', requireAuth, (req, res) => {
  res.json({ user: publicUser(req.user), config: { proPrice: PRO_PRICE, proDays: PRO_DAYS, freeLimit: FREE_LIMIT, proLimit: PRO_LIMIT } });
});

// Public: used by the landing page to show pricing and the form options.
app.get('/api/config', (req, res) => {
  res.json({
    proPrice: PRO_PRICE,
    proDays: PRO_DAYS,
    freeLimit: FREE_LIMIT,
    proLimit: PRO_LIMIT,
    types: Object.entries(ai.TYPES).map(([id, t]) => ({ id, label: t.label })),
    tones: ai.TONES,
    platforms: ai.PLATFORMS,
    languages: [
      { id: 'english', label: 'English' },
      { id: 'swahili', label: 'Swahili' },
      { id: 'mixed', label: 'English + Swahili mix' },
    ],
  });
});

// ---------- generation ----------
app.post(
  '/api/generate',
  requireAuth,
  limiter(60 * 1000, 20),
  wrap(async (req, res) => {
    const b = req.body || {};
    const input = {
      type: String(b.type || ''),
      business: clean(b.business, 80),
      offer: clean(b.offer, 400),
      audience: clean(b.audience, 200),
      tone: String(b.tone || ''),
      platform: String(b.platform || ''),
      language: String(b.language || ''),
      notes: clean(b.notes, 300),
    };
    if (!ai.TYPES[input.type]) return res.status(400).json({ error: 'Choose what you want to create' });
    if (!input.business) return res.status(400).json({ error: 'Enter your business name' });
    if (input.offer.length < 5) return res.status(400).json({ error: 'Tell us a little about what you sell' });
    if (!ai.TONES.includes(input.tone)) input.tone = 'friendly';
    if (!ai.PLATFORMS.includes(input.platform)) input.platform = 'Instagram';
    if (!ai.LANGUAGES[input.language]) input.language = 'english';

    // Reserve a generation first so parallel requests can't sneak past the limit.
    if (!consumeQuota(req.user.id, dailyLimit(req.user))) {
      return res.status(402).json({
        error: isPro(req.user)
          ? 'You have reached today\'s fair-use limit. It resets at midnight.'
          : `You have used your ${FREE_LIMIT} free generations for today. Upgrade to Pro for more.`,
        code: 'LIMIT',
      });
    }

    let output;
    try {
      output = await ai.generate(input);
    } catch (err) {
      refundQuota(req.user.id);
      console.error('generate failed:', err.message);
      if (err.code === 'NO_AI') return res.status(503).json({ error: 'The AI service is not set up yet. Please try again later.' });
      return res.status(502).json({ error: 'The AI could not answer right now. You were not charged a generation. Please try again.' });
    }

    const info = db
      .prepare('INSERT INTO generations (user_id, type, business, output) VALUES (?, ?, ?, ?)')
      .run(req.user.id, input.type, input.business, output);
    res.json({ id: info.lastInsertRowid, output, user: publicUser(req.user) });
  })
);

app.get('/api/history', requireAuth, (req, res) => {
  const rows = db
    .prepare('SELECT id, type, business, output, created_at AS createdAt FROM generations WHERE user_id = ? ORDER BY id DESC LIMIT 30')
    .all(req.user.id);
  res.json({ items: rows });
});

// ---------- payments (M-Pesa) ----------
const finalizePayment = db.transaction((checkoutId, success, receipt, paidAmount, desc) => {
  const p = db.prepare('SELECT * FROM payments WHERE checkout_request_id = ?').get(checkoutId);
  if (!p) return null;
  if (p.status !== 'pending') return p.status; // already handled: callbacks can arrive twice

  const mark = db.prepare(
    "UPDATE payments SET status = ?, mpesa_receipt = ?, result_desc = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?"
  );

  if (!success) {
    mark.run('failed', null, String(desc || 'Payment was not completed').slice(0, 200), p.id);
    return 'failed';
  }
  if (paidAmount != null && Number(paidAmount) < p.amount) {
    mark.run('failed', receipt || null, `Amount mismatch: paid ${paidAmount}, expected ${p.amount}`, p.id);
    console.error(`Payment ${p.id}: amount mismatch (paid ${paidAmount}, expected ${p.amount}), receipt ${receipt}`);
    return 'failed';
  }

  mark.run('success', receipt || null, String(desc || 'Success').slice(0, 200), p.id);
  const user = getUserById.get(p.user_id);
  const now = Date.now();
  const base = user.pro_until && new Date(user.pro_until).getTime() > now ? new Date(user.pro_until).getTime() : now;
  const until = new Date(base + PRO_DAYS * 24 * 3600 * 1000).toISOString();
  db.prepare('UPDATE users SET pro_until = ? WHERE id = ?').run(until, user.id);
  return 'success';
});

app.post(
  '/api/pay/mpesa',
  requireAuth,
  limiter(10 * 60 * 1000, 10),
  wrap(async (req, res) => {
    const phone = mpesa.normalizePhone(req.body.phone);
    if (!phone) return res.status(400).json({ error: 'Enter a valid Safaricom number, e.g. 0712345678' });
    if (!MOCK_MPESA && !mpesa.isConfigured()) return res.status(503).json({ error: 'Payments are not set up yet. Please contact support.' });

    // Don't fire a second prompt while one is likely still open on the customer's phone.
    const recent = db
      .prepare("SELECT id FROM payments WHERE user_id = ? AND status = 'pending' AND created_at > strftime('%Y-%m-%dT%H:%M:%fZ','now','-90 seconds')")
      .get(req.user.id);
    if (recent) return res.status(429).json({ error: 'A payment prompt was just sent to your phone. Check it, or wait a minute and try again.' });

    const info = db.prepare('INSERT INTO payments (user_id, phone, amount) VALUES (?, ?, ?)').run(req.user.id, phone, PRO_PRICE);
    const paymentId = Number(info.lastInsertRowid);

    try {
      let checkout;
      if (MOCK_MPESA) {
        checkout = { checkoutRequestId: `MOCK-${crypto.randomBytes(6).toString('hex')}`, merchantRequestId: 'MOCK' };
        setTimeout(() => finalizePayment(checkout.checkoutRequestId, true, `MOCK${paymentId}`, PRO_PRICE, 'Mock payment'), 5000);
      } else {
        checkout = await mpesa.stkPush({
          phone,
          amount: PRO_PRICE,
          callbackUrl: `${BASE_URL}/api/mpesa/callback/${CALLBACK_SECRET}`,
          reference: `PRO${req.user.id}`,
          description: 'Pro plan',
        });
      }
      db.prepare('UPDATE payments SET checkout_request_id = ?, merchant_request_id = ? WHERE id = ?').run(
        checkout.checkoutRequestId,
        checkout.merchantRequestId,
        paymentId
      );
      res.json({ paymentId, message: 'Check your phone and enter your M-Pesa PIN to complete the payment.' });
    } catch (err) {
      console.error('stk push failed:', err.message);
      db.prepare("UPDATE payments SET status = 'failed', result_desc = ? WHERE id = ?").run(String(err.message).slice(0, 200), paymentId);
      res.status(502).json({ error: 'Could not send the M-Pesa prompt. Please check the number and try again.' });
    }
  })
);

app.get(
  '/api/pay/status/:id',
  requireAuth,
  wrap(async (req, res) => {
    const id = Number(req.params.id);
    let p = db.prepare('SELECT * FROM payments WHERE id = ? AND user_id = ?').get(id, req.user.id);
    if (!p) return res.status(404).json({ error: 'Payment not found' });

    // No callback yet (common on localhost)? Ask Safaricom directly after a short wait.
    const ageMs = Date.now() - new Date(p.created_at).getTime();
    if (p.status === 'pending' && p.checkout_request_id && !MOCK_MPESA && ageMs > 15_000) {
      try {
        const q = await mpesa.stkQuery(p.checkout_request_id);
        if (q.state !== 'pending') finalizePayment(p.checkout_request_id, q.state === 'success', null, null, q.desc);
      } catch (err) {
        console.error('stk query failed:', err.message);
      }
      p = db.prepare('SELECT * FROM payments WHERE id = ?').get(id);
    }

    res.json({ status: p.status, message: p.status === 'failed' ? p.result_desc : undefined, user: publicUser(getUserById.get(req.user.id)) });
  })
);

// Safaricom calls this when the customer approves or cancels. The secret in the URL keeps strangers out.
app.post('/api/mpesa/callback/:secret', (req, res) => {
  const a = Buffer.from(String(req.params.secret));
  const b = Buffer.from(CALLBACK_SECRET);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.sendStatus(404);

  try {
    const cb = req.body && req.body.Body && req.body.Body.stkCallback;
    if (cb && cb.CheckoutRequestID) {
      const success = Number(cb.ResultCode) === 0;
      const items = (cb.CallbackMetadata && cb.CallbackMetadata.Item) || [];
      const pick = (name) => (items.find((i) => i.Name === name) || {}).Value;
      finalizePayment(cb.CheckoutRequestID, success, pick('MpesaReceiptNumber'), pick('Amount'), cb.ResultDesc);
    }
  } catch (err) {
    console.error('callback error:', err.message);
  }
  // Always acknowledge so Safaricom doesn't keep retrying.
  res.json({ ResultCode: 0, ResultDesc: 'Accepted' });
});

// ---------- admin ----------
app.get('/api/admin/stats', requireAuth, (req, res) => {
  if (!ADMIN_EMAIL || req.user.email !== ADMIN_EMAIL) return res.status(403).json({ error: 'Not allowed' });
  const one = (sql, ...args) => db.prepare(sql).get(...args);
  res.json({
    users: one('SELECT COUNT(*) AS n FROM users').n,
    activePro: one("SELECT COUNT(*) AS n FROM users WHERE pro_until > strftime('%Y-%m-%dT%H:%M:%fZ','now')").n,
    revenueKes: one("SELECT COALESCE(SUM(amount),0) AS n FROM payments WHERE status = 'success'").n,
    generationsTotal: one('SELECT COUNT(*) AS n FROM generations').n,
    recentPayments: db
      .prepare("SELECT p.id, u.email, p.phone, p.amount, p.status, p.mpesa_receipt AS receipt, p.created_at AS createdAt FROM payments p JOIN users u ON u.id = p.user_id ORDER BY p.id DESC LIMIT 20")
      .all(),
  });
});

app.get('/healthz', (req, res) => res.json({ ok: true }));

// ---------- static site + errors ----------
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Bad request' });
  res.status(500).json({ error: 'Something went wrong on our side' });
});

app.listen(PORT, () => {
  console.log(`Loyal DNL AI running on ${BASE_URL} (port ${PORT})`);
  if (MOCK_MPESA) console.log('M-Pesa MOCK mode is ON: payments auto-succeed after 5 seconds.');
  else if (!mpesa.isConfigured()) console.warn('M-Pesa is not configured yet: upgrades will be unavailable.');
  if (!process.env.ANTHROPIC_API_KEY) console.warn('ANTHROPIC_API_KEY is not set: generation will be unavailable.');
});
