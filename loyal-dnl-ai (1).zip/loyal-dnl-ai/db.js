const path = require('path');
const Database = require('better-sqlite3');

const db = new Database(process.env.DB_PATH || path.join(__dirname, 'data.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  email         TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  pro_until     TEXT,
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS usage (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day     TEXT NOT NULL,
  count   INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, day)
);

CREATE TABLE IF NOT EXISTS generations (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type       TEXT NOT NULL,
  business   TEXT NOT NULL,
  output     TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_generations_user ON generations(user_id, id DESC);

CREATE TABLE IF NOT EXISTS payments (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id             INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  phone               TEXT NOT NULL,
  amount              INTEGER NOT NULL,
  checkout_request_id TEXT UNIQUE,
  merchant_request_id TEXT,
  status              TEXT NOT NULL DEFAULT 'pending', -- pending | success | failed
  mpesa_receipt       TEXT,
  result_desc         TEXT,
  created_at          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_payments_user ON payments(user_id, id DESC);
`);

// "Today" for quota purposes is the Nairobi calendar day, so the free limit resets at local midnight.
function today() {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Nairobi' }).format(new Date());
}

const stmts = {
  insertUsageRow: db.prepare('INSERT OR IGNORE INTO usage (user_id, day, count) VALUES (?, ?, 0)'),
  getUsage: db.prepare('SELECT count FROM usage WHERE user_id = ? AND day = ?'),
  bumpUsage: db.prepare('UPDATE usage SET count = count + 1 WHERE user_id = ? AND day = ?'),
  refundUsage: db.prepare('UPDATE usage SET count = MAX(count - 1, 0) WHERE user_id = ? AND day = ?'),
};

// Atomically reserve one generation. Returns true if the user still had quota.
const consumeQuota = db.transaction((userId, limit) => {
  const day = today();
  stmts.insertUsageRow.run(userId, day);
  const row = stmts.getUsage.get(userId, day);
  if (row.count >= limit) return false;
  stmts.bumpUsage.run(userId, day);
  return true;
});

function refundQuota(userId) {
  stmts.refundUsage.run(userId, today());
}

function usedToday(userId) {
  const row = stmts.getUsage.get(userId, today());
  return row ? row.count : 0;
}

module.exports = { db, today, consumeQuota, refundQuota, usedToday };
