(() => {
  'use strict';

  const $ = (sel, el = document) => el.querySelector(sel);
  const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];

  let cfg = null;        // public config (pricing, option lists)
  let me = null;         // logged-in user or null
  let authMode = 'login';
  let selectedType = 'caption';
  let lastOutput = null; // { id, type, business, output } shown in the result panel
  let payPollToken = 0;  // bumping this cancels an in-progress payment poll

  // ---------- helpers ----------
  async function api(path, { method = 'GET', body } = {}) {
    const res = await fetch(`/api${path}`, {
      method,
      credentials: 'same-origin',
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const err = new Error(data.error || 'Something went wrong. Please try again.');
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  const fmtDate = (iso) => new Date(iso).toLocaleDateString('en-KE', { day: 'numeric', month: 'short', year: 'numeric' });
  const fmtDateTime = (iso) => new Date(iso).toLocaleString('en-KE', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
  const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);

  function el(tag, props = {}, children = []) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else if (k.startsWith('on')) node.addEventListener(k.slice(2), v);
      else node.setAttribute(k, v);
    }
    for (const c of [].concat(children)) node.append(c);
    return node;
  }

  function showError(node, msg) {
    node.textContent = msg;
    node.hidden = !msg;
  }

  let toastTimer;
  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg;
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (t.hidden = true), 3000);
  }

  async function copyText(text, btn) {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      // Fallback for older browsers / non-secure contexts
      const ta = el('textarea');
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      ta.value = text;
      document.body.append(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    }
    if (btn) {
      const old = btn.textContent;
      btn.textContent = 'Copied';
      setTimeout(() => (btn.textContent = old), 1500);
    } else toast('Copied');
  }

  // ---------- config-driven bits ----------
  function bindConfig() {
    for (const n of $$('[data-bind]')) {
      const v = cfg[n.dataset.bind];
      if (v !== undefined) n.textContent = v;
    }
    const fill = (id, items, getVal, getLabel, selected) => {
      const sel = $(id);
      sel.replaceChildren(...items.map((i) => {
        const o = el('option', { value: getVal(i), text: getLabel(i) });
        if (getVal(i) === selected) o.selected = true;
        return o;
      }));
    };
    fill('#sel-tone', cfg.tones, (t) => t, cap, 'friendly');
    fill('#sel-platform', cfg.platforms, (p) => p, (p) => p, 'Instagram');
    fill('#sel-language', cfg.languages, (l) => l.id, (l) => l.label, 'english');

    $('#type-seg').replaceChildren(
      ...cfg.types.map((t) =>
        el('button', {
          type: 'button',
          role: 'radio',
          'aria-checked': String(t.id === selectedType),
          'data-type': t.id,
          text: t.label,
          onclick: () => {
            selectedType = t.id;
            $$('#type-seg button').forEach((b) => b.setAttribute('aria-checked', String(b.dataset.type === selectedType)));
          },
        })
      )
    );
  }

  // ---------- rendering ----------
  function render() {
    const loggedIn = Boolean(me);
    $('#view-landing').hidden = loggedIn;
    $('#view-app').hidden = !loggedIn;

    const nav = $('#nav-right');
    nav.replaceChildren();
    if (loggedIn) {
      nav.append(
        el('span', { class: 'who', text: me.name.split(' ')[0] }),
        el('button', { class: 'btn btn-ghost btn-sm', type: 'button', text: 'Log out', onclick: logout })
      );
      renderAppHeader();
    } else {
      nav.append(
        el('button', { class: 'btn btn-ghost btn-sm', type: 'button', text: 'Log in', onclick: () => openAuth('login') }),
        el('button', { class: 'btn btn-primary btn-sm', type: 'button', text: 'Start free', onclick: () => openAuth('register') })
      );
    }
  }

  function renderAppHeader() {
    $('#welcome').textContent = `Hi ${me.name.split(' ')[0]} 👋`;
    const left = me.remainingToday;
    if (me.plan === 'pro') {
      $('#plan-line').textContent = `Pro until ${fmtDate(me.proUntil)} · ${left} of ${me.dailyLimit} generations left today`;
      $('#upgrade-btn').textContent = 'Extend Pro';
    } else {
      $('#plan-line').textContent = `Free plan · ${left} of ${me.dailyLimit} generations left today`;
      $('#upgrade-btn').textContent = 'Upgrade to Pro';
    }
  }

  // Splits "Option 1 ... Option 2 ..." into separate cards, each with its own Copy button.
  function renderResult(output) {
    const box = $('#result');
    box.classList.remove('empty');
    box.replaceChildren();

    const parts = output.split(/(?=^\s*(?:Option|Idea)\s+\d+\b)/im).map((p) => p.trim()).filter(Boolean);
    const blocks = parts.length > 1 ? parts : [output.trim()];

    for (const text of blocks) {
      const copyBtn = el('button', { class: 'btn btn-ghost btn-sm', type: 'button', text: 'Copy' });
      copyBtn.addEventListener('click', () => copyText(text, copyBtn));
      box.append(el('div', { class: 'option' }, [el('pre', { text }), el('div', { class: 'result-actions' }, [copyBtn])]));
    }
    if (blocks.length > 1) {
      const all = el('button', { class: 'btn btn-ghost btn-sm', type: 'button', text: 'Copy everything' });
      all.addEventListener('click', () => copyText(output, all));
      box.append(el('div', { class: 'result-actions' }, [all]));
    }
  }

  async function loadHistory() {
    try {
      const { items } = await api('/history');
      const list = $('#history');
      list.replaceChildren(
        ...items.map((it) => {
          const label = (cfg.types.find((t) => t.id === it.type) || {}).label || it.type;
          return el('li', {}, [
            el('div', {}, [
              el('div', { text: `${label} · ${it.business}` }),
              el('div', { class: 'meta', text: fmtDateTime(it.createdAt) }),
            ]),
            el('button', {
              class: 'btn btn-ghost btn-sm',
              type: 'button',
              text: 'View',
              onclick: () => {
                renderResult(it.output);
                $('#result').scrollIntoView({ behavior: 'smooth', block: 'center' });
              },
            }),
          ]);
        })
      );
      $('#history-empty').hidden = items.length > 0;
    } catch { /* history is non-critical */ }
  }

  async function loadAdmin() {
    $('#admin-card').hidden = true;
    if (!me || !me.isAdmin) return;
    try {
      const s = await api('/admin/stats');
      $('#admin-line').textContent =
        `${s.users} users · ${s.activePro} active Pro · KES ${Number(s.revenueKes).toLocaleString('en-KE')} revenue · ${s.generationsTotal} generations`;
      $('#admin-card').hidden = false;
    } catch { /* ignore */ }
  }

  // ---------- auth ----------
  function openAuth(mode) {
    authMode = mode;
    const dlg = $('#auth-dialog');
    $$('.tabs [data-tab]').forEach((b) => b.setAttribute('aria-selected', String(b.dataset.tab === mode)));
    $('#name-field').hidden = mode !== 'register';
    $('#auth-submit').textContent = mode === 'register' ? 'Create my account' : 'Log in';
    $('[name=password]', dlg).autocomplete = mode === 'register' ? 'new-password' : 'current-password';
    showError($('#auth-error'), '');
    if (!dlg.open) dlg.showModal();
    ($(mode === 'register' ? '[name=name]' : '[name=email]', dlg)).focus();
  }

  async function submitAuth(e) {
    e.preventDefault();
    const f = e.target;
    const btn = $('#auth-submit');
    btn.disabled = true;
    showError($('#auth-error'), '');
    try {
      const body = { email: f.email.value, password: f.password.value };
      if (authMode === 'register') body.name = f.name.value;
      const data = await api(`/auth/${authMode}`, { method: 'POST', body });
      me = data.user;
      f.reset();
      $('#auth-dialog').close();
      render();
      loadHistory();
      loadAdmin();
    } catch (err) {
      showError($('#auth-error'), err.message);
    } finally {
      btn.disabled = false;
    }
  }

  async function logout() {
    await api('/auth/logout', { method: 'POST' }).catch(() => {});
    me = null;
    lastOutput = null;
    $('#result').classList.add('empty');
    $('#result').replaceChildren(el('p', { text: 'Your captions, ideas or ads will show up here.' }));
    render();
  }

  // ---------- generate ----------
  async function submitGenerate(e) {
    e.preventDefault();
    const f = e.target;
    const btn = $('#gen-btn');
    const errBox = $('#gen-error');
    showError(errBox, '');
    btn.disabled = true;
    btn.textContent = 'Writing…';
    try {
      const data = await api('/generate', {
        method: 'POST',
        body: {
          type: selectedType,
          business: f.business.value,
          offer: f.offer.value,
          audience: f.audience.value,
          tone: f.tone.value,
          platform: f.platform.value,
          language: f.language.value,
          notes: f.notes.value,
        },
      });
      me = data.user;
      renderAppHeader();
      renderResult(data.output);
      loadHistory();
      if (window.matchMedia('(max-width: 959px)').matches) $('#result').scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (err) {
      showError(errBox, err.message);
      if (err.data && err.data.code === 'LIMIT' && me && me.plan === 'free') openPay();
      if (err.status === 401) { me = null; render(); }
    } finally {
      btn.disabled = false;
      btn.textContent = 'Generate';
    }
  }

  // ---------- payments ----------
  function setPayStatus(msg, bad = false) {
    const s = $('#pay-status');
    s.textContent = msg;
    s.hidden = !msg;
    s.classList.toggle('bad', bad);
  }

  function openPay() {
    payPollToken++;
    setPayStatus('');
    $('#pay-btn').disabled = false;
    $('#pay-btn').textContent = 'Pay with M-Pesa';
    const dlg = $('#pay-dialog');
    if (!dlg.open) dlg.showModal();
    $('[name=phone]', dlg).focus();
  }

  async function submitPay(e) {
    e.preventDefault();
    const btn = $('#pay-btn');
    btn.disabled = true;
    btn.textContent = 'Sending prompt…';
    setPayStatus('');
    try {
      const { paymentId, message } = await api('/pay/mpesa', { method: 'POST', body: { phone: e.target.phone.value } });
      setPayStatus(message);
      btn.textContent = 'Waiting for payment…';
      pollPayment(paymentId);
    } catch (err) {
      setPayStatus(err.message, true);
      btn.disabled = false;
      btn.textContent = 'Pay with M-Pesa';
    }
  }

  async function pollPayment(paymentId) {
    const token = ++payPollToken;
    for (let i = 0; i < 40; i++) { // about 2 minutes
      await new Promise((r) => setTimeout(r, 3000));
      if (token !== payPollToken) return; // dialog reopened or closed
      try {
        const r = await api(`/pay/status/${paymentId}`);
        if (r.status === 'success') {
          me = r.user;
          $('#pay-dialog').close();
          renderAppHeader();
          toast('You are now on Pro. Thank you! 🎉');
          return;
        }
        if (r.status === 'failed') {
          setPayStatus(r.message || 'The payment was not completed.', true);
          $('#pay-btn').disabled = false;
          $('#pay-btn').textContent = 'Try again';
          return;
        }
      } catch { /* network blip: keep polling */ }
    }
    if (token === payPollToken) {
      setPayStatus('Still waiting. If you already paid, Pro will switch on within a minute. Otherwise try again.', true);
      $('#pay-btn').disabled = false;
      $('#pay-btn').textContent = 'Try again';
    }
  }

  // ---------- wire up ----------
  async function init() {
    $('#year').textContent = new Date().getFullYear();

    $$('[data-open-auth]').forEach((b) => b.addEventListener('click', () => openAuth(b.dataset.openAuth)));
    $$('.tabs [data-tab]').forEach((b) => b.addEventListener('click', () => openAuth(b.dataset.tab)));
    $('#auth-form').addEventListener('submit', submitAuth);
    $('#gen-form').addEventListener('submit', submitGenerate);
    $('#pay-form').addEventListener('submit', submitPay);
    $('#upgrade-btn').addEventListener('click', openPay);
    $('#pay-dialog').addEventListener('close', () => payPollToken++);

    try {
      cfg = await api('/config');
      bindConfig();
    } catch {
      toast('Could not load the page. Please refresh.');
      return;
    }

    try {
      const r = await api('/me');
      me = r.user;
    } catch {
      me = null;
    }
    render();
    if (me) {
      loadHistory();
      loadAdmin();
    }
  }

  init();
})();
